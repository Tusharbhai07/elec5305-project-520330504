| Class | Precision | Recall | F1-score | Support |
|---|---:|---:|---:|---:|
| car_horn | 0.727 | 0.485 | 0.582 | 33 |
| dog_bark | 0.734 | 0.910 | 0.812 | 100 |
| drilling | 0.865 | 0.640 | 0.736 | 100 |
| engine_idling | 0.873 | 0.957 | 0.913 | 93 |
| siren | 0.845 | 0.590 | 0.695 | 83 |
| street_music | 0.713 | 0.920 | 0.803 | 100 |
| **Macro-F1 (overall)** |  |  | **0.757** | **509** |
