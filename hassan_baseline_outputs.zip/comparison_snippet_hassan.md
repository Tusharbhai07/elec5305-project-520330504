| Model | Classes | Test Acc | Test Macro-F1 |
|---|---:|---:|---:|
| Hassan MFCC+CNN (reproduced) | 6 | 0.788 | 0.757 |
